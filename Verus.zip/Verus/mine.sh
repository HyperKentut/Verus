./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u 1RP6ow71szqDBA7xrzSvfnA4AXbBvGPDZrC.404device -p x --cpu 7
